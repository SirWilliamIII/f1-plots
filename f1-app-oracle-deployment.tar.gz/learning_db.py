"""
Learning Database Module
Handles conversation storage and retrieval for local development learning.
"""

import sqlite3
import json
import os
from datetime import datetime
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)


def is_learning_enabled() -> bool:
    """Check if learning is enabled in the current environment."""
    return os.getenv("ENABLE_LEARNING", "false").lower() == "true"


def get_db_path() -> str:
    """Get the learning database path from environment."""
    return os.getenv("LEARNING_DB_PATH", "./local_learning.db")


def init_learning_db() -> Optional[sqlite3.Connection]:
    """
    Initialize the learning database with required tables.
    Returns None if learning is disabled.
    """
    if not is_learning_enabled():
        logger.info("Learning disabled - skipping database initialization")
        return None

    db_path = get_db_path()
    logger.info(f"Initializing learning database at: {db_path}")

    try:
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                user_query TEXT NOT NULL,
                ai_response TEXT NOT NULL,
                telemetry_context TEXT,
                race_info TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """
        )

        # Create index for faster queries
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_conversations_timestamp 
            ON conversations(timestamp DESC)
        """
        )

        conn.commit()
        logger.info("Learning database initialized successfully")
        return conn

    except Exception as e:
        logger.error(f"Failed to initialize learning database: {e}")
        return None


def store_conversation(
    user_query: str,
    ai_response: str,
    session_id: str = "unknown",
    telemetry_context: Optional[Dict] = None,
    race_info: Optional[Dict] = None,
) -> bool:
    """
    Store a conversation in the learning database.
    """
    if not is_learning_enabled():
        return False

    try:
        db_path = get_db_path()
        conn = sqlite3.connect(db_path)

        # Convert contexts to JSON strings
        telemetry_json = json.dumps(telemetry_context) if telemetry_context else None
        race_json = json.dumps(race_info) if race_info else None

        conn.execute(
            """
            INSERT INTO conversations 
            (session_id, user_query, ai_response, telemetry_context, race_info)
            VALUES (?, ?, ?, ?, ?)
        """,
            (session_id, user_query, ai_response, telemetry_json, race_json),
        )

        conn.commit()
        conn.close()

        logger.debug(f"Stored conversation for session {session_id}")
        return True

    except Exception as e:
        logger.error(f"Failed to store conversation: {e}")
        return False


def get_conversation_history(
    limit: int = 3, session_id: Optional[str] = None
) -> List[Dict]:
    """
    Retrieve recent conversation history.
    """
    if not is_learning_enabled():
        return []

    try:
        db_path = get_db_path()
        if not os.path.exists(db_path):
            return []

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row

        if session_id:
            cursor = conn.execute(
                """
                SELECT * FROM conversations 
                WHERE session_id = ?
                ORDER BY timestamp DESC 
                LIMIT ?
            """,
                (session_id, limit),
            )
        else:
            cursor = conn.execute(
                """
                SELECT * FROM conversations 
                ORDER BY timestamp DESC 
                LIMIT ?
            """,
                (limit,),
            )

        conversations = []
        for row in cursor.fetchall():
            conv = {
                "id": row["id"],
                "session_id": row["session_id"],
                "user_query": row["user_query"],
                "ai_response": row["ai_response"],
                "timestamp": row["timestamp"],
            }
            conversations.append(conv)

        conn.close()
        return conversations

    except Exception as e:
        logger.error(f"Failed to retrieve conversation history: {e}")
        return []


def clear_conversation_history() -> bool:
    """Clear all conversation history."""
    if not is_learning_enabled():
        return False

    try:
        db_path = get_db_path()
        if not os.path.exists(db_path):
            return True

        conn = sqlite3.connect(db_path)
        conn.execute("DELETE FROM conversations")
        conn.commit()
        conn.close()

        logger.info("All conversation history cleared")
        return True

    except Exception as e:
        logger.error(f"Failed to clear conversation history: {e}")
        return False


# Initialize database on module import if learning is enabled
if is_learning_enabled():
    init_learning_db()
