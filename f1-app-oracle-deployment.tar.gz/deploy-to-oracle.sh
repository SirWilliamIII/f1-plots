#!/bin/bash

# F1 Race Plots - Direct Oracle VM Deployment Script
# This script should be run directly on your Oracle VM

set -e

echo "🚀 Starting F1 Race Plots deployment on Oracle VM (141.147.90.245)..."

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Update system
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo "🐳 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    rm get-docker.sh
else
    echo "✅ Docker already installed"
fi

# Install Docker Compose if not present
if ! command -v docker-compose &> /dev/null; then
    echo "🔧 Installing Docker Compose..."
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
else
    echo "✅ Docker Compose already installed"
fi

# Install additional tools
echo "🛠️ Installing additional tools..."
sudo apt install -y htop curl wget git ufw nginx-utils jq

# Configure firewall
echo "🔒 Configuring firewall..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw allow 8080
sudo ufw --force enable

# Create app directory
echo "📁 Setting up application directory..."
sudo mkdir -p /opt/f1-app
sudo chown $USER:$USER /opt/f1-app
cd /opt/f1-app

# Create required directories
mkdir -p {fastf1_cache,static/plots,logs,ssl}

# Create optimized docker-compose for Oracle VM
echo "🔧 Creating Oracle-optimized docker-compose configuration..."
cat > docker-compose.oracle.yml << 'EOF'
version: '3.8'

services:
  flask-app:
    image: python:3.12-slim
    ports:
      - "8080:8080"
    environment:
      - OLLAMA_BASE_URL=http://ollama:11434
      - PYTHONUNBUFFERED=1
      - MATPLOTLIB_BACKEND=Agg
      - PORT=8080
      - FLASK_ENV=production
    volumes:
      - ./:/app
      - ./fastf1_cache:/app/fastf1_cache
      - ./static/plots:/app/static/plots
      - ./logs:/app/logs
    working_dir: /app
    command: >
      bash -c "
        pip install --no-cache-dir -r requirements.txt &&
        python app.py
      "
    depends_on:
      ollama:
        condition: service_healthy
    networks:
      - f1-network
    restart: unless-stopped
    mem_limit: 8g
    cpus: 2
    deploy:
      resources:
        limits:
          memory: 8g
        reservations:
          memory: 2g

  ollama:
    image: ollama/ollama:latest
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    networks:
      - f1-network
    restart: unless-stopped
    environment:
      - OLLAMA_KEEP_ALIVE=24h
      - OLLAMA_HOST=0.0.0.0
      - OLLAMA_ORIGINS=*
      - OLLAMA_NUM_PARALLEL=2
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:11434/api/tags"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 180s
    mem_limit: 12g
    cpus: 4
    deploy:
      resources:
        limits:
          memory: 12g
        reservations:
          memory: 8g

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - flask-app
    networks:
      - f1-network
    restart: unless-stopped
    mem_limit: 512m

volumes:
  ollama_data:

networks:
  f1-network:
    driver: bridge
EOF

# Create nginx configuration
echo "🌐 Creating nginx configuration..."
cat > nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    upstream flask_app {
        server flask-app:8080;
    }

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=static:10m rate=50r/s;

    server {
        listen 80;
        listen [::]:80;
        server_name _;

        # Security headers
        add_header X-Frame-Options DENY;
        add_header X-Content-Type-Options nosniff;
        add_header X-XSS-Protection "1; mode=block";
        add_header Referrer-Policy strict-origin-when-cross-origin;

        # Gzip compression
        gzip on;
        gzip_vary on;
        gzip_min_length 1024;
        gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

        # Static files
        location /static/ {
            limit_req zone=static burst=20 nodelay;
            proxy_pass http://flask_app;
            proxy_cache_valid 200 1h;
            expires 1h;
        }

        # Main application
        location / {
            limit_req zone=api burst=10 nodelay;
            proxy_pass http://flask_app;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # Health check endpoint
        location /health {
            access_log off;
            return 200 "healthy\n";
            add_header Content-Type text/plain;
        }
    }
}
EOF

# Create systemd service
echo "🔄 Creating systemd service..."
sudo tee /etc/systemd/system/f1-app.service > /dev/null <<EOF
[Unit]
Description=F1 Race Plots Application
After=docker.service network.target
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/f1-app
ExecStart=/usr/local/bin/docker-compose -f docker-compose.oracle.yml up -d
ExecStop=/usr/local/bin/docker-compose -f docker-compose.oracle.yml down
ExecReload=/usr/local/bin/docker-compose -f docker-compose.oracle.yml restart
TimeoutStartSec=300
User=$USER
Group=docker
Environment=PATH=/usr/local/bin:/usr/bin:/bin

[Install]
WantedBy=multi-user.target
EOF

# Enable the service
sudo systemctl daemon-reload
sudo systemctl enable f1-app.service

# Create management scripts
echo "📊 Creating management scripts..."

# Health check script
tee ~/f1-health.sh > /dev/null <<'EOF'
#!/bin/bash
echo "=== F1 App Health Check $(date) ==="
echo ""

# Check services
echo "🐳 Docker Services:"
cd /opt/f1-app && docker-compose -f docker-compose.oracle.yml ps

echo ""
echo "🌐 Service Health:"
echo -n "Flask App (port 8080): "
timeout 5 curl -s -f http://localhost:8080/ > /dev/null && echo "✅ Running" || echo "❌ Down"

echo -n "Ollama (port 11434): "
timeout 5 curl -s -f http://localhost:11434/api/tags > /dev/null && echo "✅ Running" || echo "❌ Down"

echo -n "Nginx (port 80): "
timeout 5 curl -s -f http://localhost:80/health > /dev/null && echo "✅ Running" || echo "❌ Down"

echo ""
echo "💻 System Resources:"
echo "Memory: $(free -h | awk '/^Mem:/ {print $3 "/" $2 " (" int($3/$2*100) "%)"}')"
echo "Disk: $(df -h /opt/f1-app | awk 'NR==2 {print $3 "/" $2 " (" $5 ")"}')"
echo "Load: $(uptime | awk -F'load average:' '{print $2}' | sed 's/^[ \t]*//')"
echo "Docker: $(docker system df --format 'table {{.Type}}\t{{.TotalCount}}\t{{.Size}}\t{{.Reclaimable}}')"

echo ""
echo "📈 Recent Logs (last 10 lines):"
cd /opt/f1-app && docker-compose -f docker-compose.oracle.yml logs --tail=10 flask-app
EOF
chmod +x ~/f1-health.sh

# Management script
tee ~/f1-manage.sh > /dev/null <<'EOF'
#!/bin/bash
cd /opt/f1-app

case "$1" in
    start)
        echo "🚀 Starting F1 App..."
        docker-compose -f docker-compose.oracle.yml up -d
        ;;
    stop)
        echo "🛑 Stopping F1 App..."
        docker-compose -f docker-compose.oracle.yml down
        ;;
    restart)
        echo "🔄 Restarting F1 App..."
        docker-compose -f docker-compose.oracle.yml restart
        ;;
    logs)
        echo "📋 Showing logs..."
        docker-compose -f docker-compose.oracle.yml logs -f ${2:-flask-app}
        ;;
    update)
        echo "🔄 Updating F1 App..."
        git pull
        docker-compose -f docker-compose.oracle.yml down
        docker-compose -f docker-compose.oracle.yml build --no-cache
        docker-compose -f docker-compose.oracle.yml up -d
        ;;
    status)
        ~/f1-health.sh
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|logs|update|status}"
        echo ""
        echo "Commands:"
        echo "  start   - Start all services"
        echo "  stop    - Stop all services"
        echo "  restart - Restart all services"
        echo "  logs    - Show logs (add service name for specific service)"
        echo "  update  - Pull latest code and rebuild"
        echo "  status  - Show health status"
        ;;
esac
EOF
chmod +x ~/f1-manage.sh

# Check system architecture
ARCH=$(uname -m)
if [[ "$ARCH" == "aarch64" ]]; then
    echo "🎯 Detected ARM64 architecture - Oracle Always Free Tier eligible!"
else
    echo "🖥️ Detected x86_64 architecture"
fi

# Get public IP
PUBLIC_IP=$(curl -s ifconfig.me || curl -s icanhazip.com || echo "Unable to detect")

echo ""
echo "🎉 Oracle VM deployment setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Copy your F1 app files to /opt/f1-app/"
echo "2. Start the application: ~/f1-manage.sh start"
echo "3. Check status: ~/f1-manage.sh status"
echo "4. View logs: ~/f1-manage.sh logs"
echo ""
echo "🌍 Your public IP: $PUBLIC_IP"
echo "🔗 App will be available at: http://$PUBLIC_IP"
echo ""
echo "⚡ Quick commands:"
echo "  - Health check: ~/f1-health.sh"
echo "  - Manage app: ~/f1-manage.sh {start|stop|restart|status|logs}"
echo "  - System service: sudo systemctl {start|stop|restart|status} f1-app"
echo ""
echo "🔧 Oracle Cloud Security List Requirements:"
echo "  - Allow Ingress: Port 80 (HTTP) from 0.0.0.0/0"
echo "  - Allow Ingress: Port 443 (HTTPS) from 0.0.0.0/0"
echo "  - Allow Ingress: Port 22 (SSH) from your IP"