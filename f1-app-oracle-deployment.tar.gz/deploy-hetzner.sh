#!/bin/bash

# Hetzner F1 Race Plots + Ollama Deployment Script
# Run this on your fresh Hetzner Ubuntu server

set -e

echo "🚀 Starting F1 Race Plots + Ollama deployment on Hetzner..."

# Update system
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Docker
echo "🐳 Installing Docker..."
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
echo "🔧 Installing Docker Compose..."
sudo curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install useful tools
echo "🛠️ Installing additional tools..."
sudo apt install -y htop curl wget git ufw

# Configure firewall
echo "🔒 Configuring firewall..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw --force enable

# Create app directory
echo "📁 Creating application directory..."
mkdir -p ~/f1-app
cd ~/f1-app

# Create SSL directory (you'll need to add your certificates)
mkdir -p ssl
echo "⚠️  Don't forget to add your SSL certificates to ~/f1-app/ssl/"

# Create systemd service for auto-start
echo "🔄 Creating systemd service..."
sudo tee /etc/systemd/system/f1-app.service > /dev/null <<EOF
[Unit]
Description=F1 Race Plots Application
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/home/$USER/f1-app
ExecStart=/usr/local/bin/docker-compose -f docker-compose.prod.yml up -d
ExecStop=/usr/local/bin/docker-compose -f docker-compose.prod.yml down
TimeoutStartSec=0
User=$USER

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable f1-app.service

# Setup log rotation
echo "📊 Setting up log rotation..."
sudo tee /etc/logrotate.d/f1-app > /dev/null <<EOF
/home/$USER/f1-app/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 644 $USER $USER
}
EOF

# Create monitoring script
echo "📈 Creating monitoring script..."
tee ~/monitor.sh > /dev/null <<'EOF'
#!/bin/bash
echo "=== F1 App Status ==="
docker-compose -f ~/f1-app/docker-compose.prod.yml ps
echo ""
echo "=== System Resources ==="
free -h
echo ""
df -h
echo ""
echo "=== Docker Stats ==="
docker stats --no-stream
EOF
chmod +x ~/monitor.sh

echo ""
echo "🎉 Deployment setup complete!"
echo ""
echo "Next steps:"
echo "1. Upload your F1 app code to ~/f1-app/"
echo "2. Add SSL certificates to ~/f1-app/ssl/ (cert.pem and key.pem)"
echo "3. Run: cd ~/f1-app && docker-compose -f docker-compose.prod.yml up -d"
echo "4. Monitor with: ~/monitor.sh"
echo ""
echo "💰 Total monthly cost: ~$9 USD (CAX31 instance)"
echo "🌍 Your app will be available at: https://your-server-ip"