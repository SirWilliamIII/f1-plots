# F1 Race Plots + Ollama - Hetzner Deployment

Deploy your F1 telemetry analysis app with custom Ollama AI model on Hetzner for **~$16/month**.

## 🚀 Quick Start

### 1. Create Hetzner Server
- Go to [Hetzner Cloud Console](https://console.hetzner-cloud.com/)
- Create new server:
  - **Location:** Ashburn, VA (us-east)
  - **Image:** Ubuntu 22.04
  - **Type:** CAX31 (8GB RAM, 4 vCPU ARM) - €8.21/month
  - **SSH Key:** Add your public key

### 2. Initial Server Setup
```bash
# SSH into your server
ssh root@YOUR_SERVER_IP

# Run the deployment script
curl -fsSL https://raw.githubusercontent.com/your-repo/deploy-hetzner.sh | bash

# Reboot to ensure Docker group membership
sudo reboot
```

### 3. Deploy Your App
```bash
# SSH back in after reboot
ssh root@YOUR_SERVER_IP

# Clone your app (or upload files)
cd ~/f1-app
# Upload your F1 app files here

# Start the application
docker-compose -f docker-compose.prod.yml up -d
```

## 📋 What Gets Deployed

### Services
- **Flask App** (Port 8080) - Your F1 telemetry analyzer
- **Ollama** (Port 11434) - AI with your custom f1expert model  
- **Nginx** (Ports 80/443) - Reverse proxy with SSL

### Resource Allocation
- **Flask App:** 4GB RAM, 2 CPUs
- **Ollama:** 10GB RAM, 4 CPUs
- **Nginx:** Minimal resources

## 🔧 Configuration

### SSL Certificates
```bash
# Add your SSL certificates
mkdir -p ~/f1-app/ssl
# Copy your cert.pem and key.pem files to this directory
```

### Environment Variables
```bash
# Copy and edit the production environment file
cp .env.prod .env
nano .env
```

## 📊 Monitoring

### Check Status
```bash
~/monitor.sh
```

### View Logs
```bash
cd ~/f1-app
docker-compose -f docker-compose.prod.yml logs -f flask-app
docker-compose -f docker-compose.prod.yml logs -f ollama
```

### Resource Usage
```bash
htop
docker stats
```

## 🛠️ Maintenance

### Update Application
```bash
cd ~/f1-app
docker-compose -f docker-compose.prod.yml pull
docker-compose -f docker-compose.prod.yml up -d
```

### Restart Services
```bash
sudo systemctl restart f1-app
```

### Backup Data
```bash
# Backup FastF1 cache and plots
tar -czf backup-$(date +%Y%m%d).tar.gz fastf1_cache/ static/plots/ logs/
```

## 💰 Cost Breakdown

**Hetzner CAX31:** €8.21/month (~$9 USD)
- 8GB RAM
- 4 vCPU ARM64
- 80GB SSD
- 20TB traffic

**Total:** ~$9/month vs $150-200/month on AWS/GCP

## 🚨 Troubleshooting

### Ollama Model Issues
```bash
# Check if f1expert model is loaded
curl http://localhost:11434/api/tags

# Rebuild Ollama container if needed
docker-compose -f docker-compose.prod.yml up -d --build ollama
```

### High Memory Usage
```bash
# Check memory usage
free -h
docker stats

# Restart if needed
docker-compose -f docker-compose.prod.yml restart
```

### SSL Issues
- Ensure cert.pem and key.pem are in ~/f1-app/ssl/
- Check nginx logs: `docker-compose logs nginx`

## 🎯 Performance Tips

1. **ARM Optimization:** CAX instances use ARM processors - very efficient for AI workloads
2. **Keep Ollama Warm:** OLLAMA_KEEP_ALIVE=24h prevents model unloading
3. **Cache FastF1 Data:** Persistent volume speeds up race data loading
4. **Monitor Resources:** Use ~/monitor.sh to track usage

Your F1 analysis app with custom AI is now running for the cost of a Netflix subscription! 🏎️